import subprocess

subprocess.run("python3 instruction_app.py", shell=True)
subprocess.run("python3 disclaimer.py", shell=True)
subprocess.run("python3 test.py", shell=True)
subprocess.run("python3 exit.py", shell=True)


